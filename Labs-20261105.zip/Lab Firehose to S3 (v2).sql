-- Lab: From Events to Files in S3 with Amazon Data Firehose
-- Run each statement on its own.

-- Step 5, S3 Select (one object under ticks/): select the object, then Actions > Query with S3 Select.
-- Input format: JSON; JSON content type: JSON Lines; Output format: JSON. No semicolon at the end.
SELECT * FROM s3object s LIMIT 5

-- Step 6, Athena: database for the lab
CREATE DATABASE IF NOT EXISTS streamlab;

-- Step 6, Athena: table over the folder ticks/ (replace YOUR-EVENTS-BUCKET)
CREATE EXTERNAL TABLE streamlab.stock_ticks (
  ticker_symbol string,
  sector        string,
  change        double,
  price         double
)
ROW FORMAT SERDE 'org.openx.data.jsonserde.JsonSerDe'
LOCATION 's3://YOUR-EVENTS-BUCKET/ticks/';

-- Step 6, Athena: how many events were delivered, per sector
SELECT sector, count(*) AS events, round(avg(price), 2) AS avg_price
FROM streamlab.stock_ticks
GROUP BY sector
ORDER BY events DESC;

-- Clean up, Athena
DROP TABLE IF EXISTS streamlab.stock_ticks;

DROP DATABASE IF EXISTS streamlab;
